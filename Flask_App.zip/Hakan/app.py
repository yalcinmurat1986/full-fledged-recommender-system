
from flask import Flask, render_template, flash, redirect, url_for, request



######### imports for model #######################
import pandas as pd
import numpy as np

import string
import re

#from nltk.stem.porter import *
from nltk.tokenize import word_tokenize, sent_tokenize


import warnings
warnings.filterwarnings('ignore')

import torch
import torch.nn as nn
import torch.nn.parallel
import torch.optim as optim
import torch.utils.data
from torch.autograd import Variable
import pickle
from sklearn.preprocessing import LabelEncoder
######### imports for model #######################

app = Flask(__name__)

data = pd.read_csv('dataset_food_online.txt', sep=',', encoding = 'latin-1')

labelbusines = LabelEncoder()
labelreview = LabelEncoder()
labeluser = LabelEncoder()
data.business_id = labelbusines.fit_transform(data.business_id)
data.review_id = labelreview.fit_transform(data.review_id)
data.user_id = labeluser.fit_transform(data.user_id)
data = data.sort_values('user_id')
data1 = data
# Getting the number of users and businesses
nb_users = data.user_id.nunique()
nb_business = data.business_id.nunique()

# Converting the data into an array with customers in lines and businesses in columns
def convert(data):
    new_data = []
    for id_users in range(nb_users):
        id_business = data.business_id[data.user_id == id_users]
        id_ratings = data.stars[data.user_id == id_users]
        ratings = np.zeros(nb_business)
        ratings[id_business] = id_ratings
        new_data.append(list(ratings))
    return new_data

data = convert(data)
# Converting the data into Torch tensors
data = torch.FloatTensor(data)
datasae = data
# Converting the ratings into binary ratings 1 (Liked) or 0 (Not Liked)
data[data == 0] = -1
data[data == 1] = 0
data[data == 2] = 0
data[data >= 3] = 1

business_features = ['veggie','pizza','breakfast','steakhouse','chicken','mediterranean','mexican','chinese','seafood','italian','korean','american','sushi','vietnamese',
                    'ufc','sesame chicken','meat chicken','shank','shave','fast food',
                    'cafe','dining','bar','barbecue','bistro','food truck','sandwich','blues',
                    'self-service','food burger','family','scottsdale','farmer market',
                    'cheap','expensive']
business_features_df = pd.read_csv('business_features_df.csv')



stop = [ "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are", "as", "at", "be", "because", "been", "before", "being", "below", "between", "both", "but", "by", "could", "did", "do", "does", "doing", "down", "during", "each", "few", "for", "from", "further", "had", "has", "have", "having", "he", "he'd", "he'll", "he's", "her", "here", "here's", "hers", "herself", "him", "himself", "his", "how", "how's", "i", "i'd", "i'll", "i'm", "i've", "if", "in", "into", "is", "it", "it's", "its", "itself", "let's", "me", "more", "most", "my", "myself", "nor", "of", "on", "once", "only", "or", "other", "ought", "our", "ours", "ourselves", "out", "over", "own", "same", "she", "she'd", "she'll", "she's", "should", "so", "some", "such", "than", "that", "that's", "the", "their", "theirs", "them", "themselves", "then", "there", "there's", "these", "they", "they'd", "they'll", "they're", "they've", "this", "those", "through", "to", "too", "under", "until", "up", "very", "was", "we", "we'd", "we'll", "we're", "we've", "were", "what", "what's", "when", "when's", "where", "where's", "which", "while", "who", "who's", "whom", "why", "why's", "with", "would", "you", "you'd", "you'll", "you're", "you've", "your", "yours", "yourself", "yourselves" ]

def tokenize(text):
    """
    sent_tokenize(): segment text into sentences
    word_tokenize(): break sentences into words
    """
    try: 
        regex = re.compile('[' +re.escape(string.punctuation) + '0-9\\r\\t\\n]')
        text = regex.sub(" ", text) # remove punctuation
        
        tokens_ = [word_tokenize(s) for s in sent_tokenize(text)]
        tokens = []
        for token_by_sent in tokens_:
            tokens += token_by_sent
        tokens = list(filter(lambda t: t.lower() not in stop, tokens))
        filtered_tokens = [w for w in tokens if re.search('[a-zA-Z]', w)]
        filtered_tokens = [w.lower() for w in filtered_tokens if len(w)>=3]
        
        return filtered_tokens
            
    except TypeError as e: print(text,e)

# Creating the architecture of the Neural Network
class RBM():
    def __init__(self, nv, nh): # nv = number of visible nodes, vh = number of hidden nodes
        # initialize weights and bias using torch random number generator
        self.W = torch.randn(nh, nv)
        self.a = torch.randn(1, nh) # bias for hidden nodes
        self.b = torch.randn(1, nv) # bias for visible nodes
    def sample_h(self, x): # x = visible neurons v, in the probabilities (ph given v (sigmoid))
        wx = torch.mm(x, self.W.t())
        activation = wx + self.a.expand_as(wx) # add bias
        p_h_given_v = torch.sigmoid(activation) # apply activation
        return p_h_given_v, torch.bernoulli(p_h_given_v)
    def sample_v(self, y):
        wy = torch.mm(y, self.W)
        activation = wy + self.b.expand_as(wy)
        p_v_given_h = torch.sigmoid(activation)
        return p_v_given_h, torch.bernoulli(p_v_given_h)
    def train(self, v0, vk, ph0, phk):
        #self.W += torch.mm(v0.t(), ph0) - torch.mm(vk.t(), phk)
        self.W += (torch.mm(v0.t(),ph0) - torch.mm(vk.t(),phk)).t()
        self.b += torch.sum((v0 - vk), 0)
        self.a += torch.sum((ph0 - phk), 0)

rbm = pickle.load(open('rbm.pk', 'rb'))

def predict(id_user):
    v = data[id_user:id_user+1]
    #vt = test_set[id_user:id_user+1]
    _,h = rbm.sample_h(v)
    _,v = rbm.sample_v(h) 
    return v

# Auto Encoders
# Creating the architecture of the Neural Network
class SAE(nn.Module):
    def __init__(self, ):
        super(SAE, self).__init__()
        self.fc1 = nn.Linear(nb_business, 20)
        self.fc2 = nn.Linear(20, 10)
        self.fc3 = nn.Linear(10, 20)
        self.fc4 = nn.Linear(20, nb_business)
        self.activation = nn.Sigmoid()
    def forward(self, x):
        x = self.activation(self.fc1(x))
        x = self.activation(self.fc2(x))
        x = self.activation(self.fc3(x))
        x = self.fc4(x)
        return x
        
sae = pickle.load(open('sae.pk', 'rb'))

# Predict the SAE
def predictAE(id_user):
    input = Variable(datasae[id_user]).unsqueeze(0)
    output = sae(input)
    return output



@app.route('/', methods = ['GET', 'POST'])
def home():

    return render_template('home.html',**locals())


@app.route('/results', methods = ['GET', 'POST'])
def run():

    user = request.form['user']
    print('first user is',user,'type is', type(user))
    input = request.form['userinput']
    print(input)
    
    try:
        user = int(user)
        print('later user is',user,'type is', type(user))
    except:
        flash('User id should be an integer','danger')
        return redirect(url_for('home'))
    if user > 6402:
        flash('User id should be less than 6402','danger')
        return redirect(url_for('home'))
    # Tokenize input
    tokens = tokenize(input)
    # Find non duplicate matches
    matches = list({x for x in tokens if x in business_features})
    
    if matches:
        
        # pull the businesses with these features
        business = []
        for i in range(business_features_df.shape[0]):
            if (business_features_df[matches] == 1).iloc[i].sum()==1:
                business.append(i)

        business_index = business_features_df.iloc[business].index
        
        prediction = predict(user)
        a = np.array(prediction[0][business_index])
        b =a.astype(bool)
        # get the businesses with the highest rating and recommend to the customer
        recommendation = list(data1.groupby('business_id').stars.mean().loc[business_index[b]].sort_values(ascending = False).index[:3])

        if len(recommendation) < 3:
            result = predictAE(user)
            result = result[0].detach().numpy()
            ind = list(np.argpartition(result, -3)[-3:])
            recommendation  = (recommendation + ind)[0:3]

        if len(recommendation) < 3:
            prediction = predict(user)
            prediction = prediction[0].detach().numpy()
            ind = list(np.argpartition(prediction, -3)[-3:])
            recommendation  = (recommendation + ind)[0:3]
        
        if len(recommendation) < 3:
            randnum = np.random.randint(20,size=1)[0]
            ind = list(data1.groupby('business_id').stars.mean().sort_values(ascending = False).index[randnum:randnum+3])
            recommendation  = (recommendation + ind)[0:3]

    else:
        result = predictAE(user)
        result = result[0].detach().numpy()
        ind = list(np.argpartition(result, -3)[-3:])
        recommendation  = ind
        
        if len(recommendation) < 3:
            prediction = predict(user)
            prediction = prediction[0].detach().numpy()
            ind = list(np.argpartition(prediction, -3)[-3:])
            recommendation  = (recommendation + ind)[0:3]
        
        if len(recommendation) < 3:
            randnum = np.random.randint(20,size=1)[0]
            ind = list(data1.groupby('business_id').stars.mean().sort_values(ascending = False).index[randnum:randnum+3])
            recommendation  = (recommendation + ind)[0:3]

    return render_template('results.html', **locals())



@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

if __name__ == '__main__':
    app.secret_key='secret123'
    app.run()
